package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
	// write your code here
        Scanner teclado=new Scanner(System.in);
        double factorial;
        int numero;

        System.out.print("Introduzca un número: ");
        numero=teclado.nextInt();

        factorial=1;
        for(int i=numero; i>0; i--){
            factorial=factorial*i;
        }
        System.out.print("El facotiral de " + numero + " es "+ factorial);
    }
}
