package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
	// write your code here
        Scanner teclado= new Scanner(System.in);
        int suma_edades=0;
        int contador_alumnos=0;
        int contador_mayor_edad=0;

        double media;

        System.out.print("Introduzca la edad: " );
        int edad=teclado.nextInt();

        while (edad >=0){
            suma_edades +=edad;
            contador_alumnos++;
            if (edad>=18){
                contador_mayor_edad++;
            }
            System.out.print("Introduzca la edad: ");
            edad=teclado.nextInt();
        }
        media=(double) suma_edades/contador_alumnos;

        System.out.println("Suma de todas las edades: " + suma_edades);
        System.out.println("La media es " + media);
        System.out.println("Número total de alumnos "+ contador_alumnos);
        System.out.println("Mayores de edad " + contador_mayor_edad);


    }
}
