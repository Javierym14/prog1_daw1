package com.company;

public class Main {

    public static void main(String[] args) {
	// write your code here
        int producto=1;
        for (int i=1; i<20; i+=2){
            producto=producto*i;
        }
        System.out.print("El producto de los 10 primeros números impares es: "+ producto);
    }
}
