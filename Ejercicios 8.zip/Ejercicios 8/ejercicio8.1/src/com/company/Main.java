package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
	// write your code here
        Scanner teclado;
        int numero;
        boolean par, positivo;
        teclado=new Scanner(System.in);
        System.out.print("Introduce un número: ");
        numero =teclado.nextInt();

        while (numero != 0){
            par = numero % 2 == 0 ? true : false;
            positivo = numero >=0 ? true : false;

            System.out.println("Es par: " + par +  " Es positivo: " + positivo);
            System.out.println("El cuadrado " + numero * numero);
            System.out.println("Introduzca otro número: ");
            numero=teclado.nextInt();
        }
    }
}
