package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        // write your code here
        Scanner teclado = new Scanner(System.in);
        boolean suspensos = false;

        for (int i = 0; i < 5; i++) {
            System.out.print("Introduzca la nota:");
            int notas = teclado.nextInt();

            if (notas < 5) {
                suspensos = true;
            }
        }
        if (suspensos) {
            System.out.print("Hay alumnos suspensos");
        } else {
            System.out.print("No hay suspensos");
        }
    }
}
