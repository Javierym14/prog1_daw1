package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        // write your code here
        int numero;
        Scanner teclado = new Scanner(System.in);
        System.out.print("Introduzca un número entre el 1 y el 10: ");
        numero = teclado.nextInt();
        if (numero >= 1 && numero <= 10) {
            for (int i = 1; i <= 10; i++) {
                System.out.println(numero+ "x" + i + "=" + numero*i);
            }
        }else {
            System.out.print("No está entre 1 y 10");
        }


    }



}

