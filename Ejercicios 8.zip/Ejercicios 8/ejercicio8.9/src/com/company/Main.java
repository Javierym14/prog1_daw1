package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
	// write your code here
        int altura;
        int etiqueta=0;
        Scanner teclado=new Scanner(System.in);
        int etiqueta_arbol_mas_alto;
        int altura_arbol_mas_alto;
        System.out.print("Altura del árbol "+ etiqueta+ ":");
        altura=teclado.nextInt();
        altura_arbol_mas_alto=altura;
        etiqueta_arbol_mas_alto=0;

        while(altura!=-1){
            if(altura>altura_arbol_mas_alto){
                altura_arbol_mas_alto=altura;
                etiqueta_arbol_mas_alto=etiqueta;
            }
            etiqueta++;
            System.out.print("Altura del árbol "+ etiqueta + ":");
            altura=teclado.nextInt();
        }
        if(altura_arbol_mas_alto==-1){
            System.out.print("No hay ningún árbol");
        }else{
            System.out.println("El árbol más alto mide "+ altura_arbol_mas_alto);
            System.out.println("Es el árbol " + etiqueta_arbol_mas_alto);
        }

    }
}
