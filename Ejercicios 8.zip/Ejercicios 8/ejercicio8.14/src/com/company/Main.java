package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
	// write your code here
        Scanner teclado=new Scanner(System.in);
        System.out.print("Introduce n:");
        int n=teclado.nextInt();

        for(int fila=1; fila<=n; fila++){
            for(int columna=fila; columna<=n; columna++){
                System.out.print("* ");
            }
            System.out.println("");
        }
    }
}
