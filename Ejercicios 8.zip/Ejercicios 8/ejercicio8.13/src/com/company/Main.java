package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
	// write your code here
        Scanner teclado=new Scanner(System.in);
        int aprobados=0;
        int suspensos=0;
        int condicionados=0;

        for(int i=1; i<=6; i++){
            System.out.print("Nota del alumno "+ i+ ": ");
            int nota=teclado.nextInt();
            if (nota==4){
                condicionados++;
            }else{
                if(nota>=5){
                    aprobados++;
                }else{
                    if(nota<4){
                        suspensos++;
                    }
                }
                System.out.println("Aprobados "+ aprobados);
                System.out.println("Suspensos "+ suspensos);
                System.out.println("Condicionados "+ condicionados);
            }
        }
    }
}
