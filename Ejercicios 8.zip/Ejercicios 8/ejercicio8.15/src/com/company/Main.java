package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
	// write your code here
        Scanner teclado=new Scanner(System.in);
        int x=0;
        int contador_primos=0;
        boolean primo;

        System.out.print("Introduce n:");
        int n=teclado.nextInt();
        for(int i=1;i<=n;i++){
            primo=true;
            x=2;
            while (x<=i-1 && primo==true){
                if(i%x==0){
                    primo=false;
                }
                x++;
            }
            if(primo){
                contador_primos++;
                System.out.println(i + " es primo");
            }
        }
        System.out.print("De 1 a "+ n + " hay " + contador_primos+ " primos");
    }
}
