package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        // write your code here



            for (int tablas = 1; tablas <= 10; tablas++) {
                for (int i = 1; i <= 10; i++){
                    System.out.println(tablas + "x" + i + "=" + tablas*i);
                }
            }
        }
        }







