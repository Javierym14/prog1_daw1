package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
	// write your code here
        int numero, min, max;
        Scanner teclado=new Scanner(System.in);
        System.out.print("Introduce el valor mínimo del rango: ");
        min=teclado.nextInt();
        System.out.print("Introduce el valor máximo del rango: ");
        max=teclado.nextInt();

        do{
            System.out.print("Introduce un número: ");
            numero=teclado.nextInt();

        }while (!(min<=numero && numero<=max));
        System.out.print(numero + "pertence al rango");


    }
}
