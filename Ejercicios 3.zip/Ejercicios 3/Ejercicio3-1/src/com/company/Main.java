package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        // write your code here
        Scanner teclado;
        byte primerNumero, segundoNumero;

        teclado=new Scanner(System.in);
        System.out.print("Introduzca el primer número:");
        primerNumero=teclado.nextByte();
        System.out.print("Introduzca el segundo número:");
        segundoNumero=teclado.nextByte();
        System.out.print(primerNumero + segundoNumero);
    }
}
