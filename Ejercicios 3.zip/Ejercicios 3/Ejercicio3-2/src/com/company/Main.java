package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
	// write your code here
        Scanner teclado;
        short nacimiento, actual;

        teclado=new Scanner(System.in);
        System.out.print("El año de su nacimiento:");
        nacimiento=teclado.nextShort();
        System.out.print("El año actual:");
        actual=teclado.nextShort();
        System.out.print(actual - nacimiento);
        System.out.print(" años");
    }
}
