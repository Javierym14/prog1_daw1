package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        // write your code here
        Scanner teclado;
        int tiempo;
        float gravedad=9.8f;
        teclado = new Scanner(System.in);
        System.out.print("Introduce el tiempo: ");
        tiempo = teclado.nextInt();
        if (tiempo == 0) {
            System.out.print("Tiempo incorrecto: ");
        } else {
            System.out.print("La velocidad es " + tiempo * gravedad);
        }


    }
}