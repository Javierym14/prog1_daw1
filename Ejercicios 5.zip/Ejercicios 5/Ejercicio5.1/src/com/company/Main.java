package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
	// write your code here
        Scanner teclado;
        int numero1;

        teclado=new Scanner(System.in);
        System.out.print("Introduce un número:");
        numero1=teclado.nextInt();


       if (numero1<0) {
           System.out.print("El número es menor que 0");
       } else {
           if (numero1>0) {
                System.out.print("El número es mayor que 0");
           }
       }


    }
}
