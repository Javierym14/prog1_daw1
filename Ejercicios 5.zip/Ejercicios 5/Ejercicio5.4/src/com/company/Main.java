package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
	// write your code here
        Scanner teclado;
        int numero1, numero2;

        teclado=new Scanner(System.in);
        System.out.print("Introduce un número: ");
        numero1 =teclado.nextInt();
        System.out.print("Introduce otro un número: ");
        numero2 =teclado.nextInt();

        if(numero1 % 2 == 0 && numero2 % 2 == 0){
            System.out.print("Los 2 son pares");
        }else{
            if(numero1 % 2 == 0 || numero2 % 2 == 0){
                System.out.print("Solo uno es par");
            }else{
                System.out.print("Ninguno es par");
            }



        }

        }
    }

