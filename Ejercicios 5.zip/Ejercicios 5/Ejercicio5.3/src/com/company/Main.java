package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
	// write your code here
        Scanner teclado;
        int numero;

        teclado=new Scanner(System.in);
        System.out.print("Introduce un número: ");
        numero=teclado.nextInt();
        if (numero%2==0) {
            System.out.print("El número no es impar");
        } else {
            System.out.print("El número es impar");
        }
    }
}
