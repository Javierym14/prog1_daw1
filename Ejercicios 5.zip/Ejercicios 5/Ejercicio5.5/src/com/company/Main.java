package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
	// write your code here
        Scanner teclado;
        int numero1, numero2, numero3;

        teclado=new Scanner(System.in);
        System.out.print("Introduce un número: ");
        numero1=teclado.nextInt();
        teclado=new Scanner(System.in);
        System.out.print("Introduce otro un número: ");
        numero2=teclado.nextInt();
        teclado=new Scanner(System.in);
        System.out.print("Introduce otro un número: ");
        numero3=teclado.nextInt();

        if (numero1>numero2 && numero1>numero3){
            System.out.print("El primer número es el mayor");
        }else{
            if(numero2>numero1 && numero2>numero3){
                System.out.print("El segundo número es el mayor");
            }
        }
        if (numero3>numero1 && numero3>numero2){
            System.out.print("El tercer número es el mayor");
        }

    }
}
