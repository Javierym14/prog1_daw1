package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
	// write your code here
        Scanner teclado;
        int numero;

        teclado=new Scanner(System.in);
        System.out.print("Introduce el número 12:");
        numero=teclado.nextInt();

        if (numero==12) {
            System.out.print("Es correcto");
        } else {
            System.out.print("No es correcto");
        }

    }
}
