package com.company;

import java.util.Locale;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
	// write your code here
        double x;
        int redondeo;
        Scanner teclado=new Scanner(System.in);
        teclado.useLocale(Locale.US);

        System.out.print("Escribe un número decimal: ");
        x=teclado.nextDouble();
        redondeo=(int) (x+0.5);

        System.out.println(x + " el redonde es: "+ redondeo );
    }
}
