package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
	// write your code here
        int nota1, nota2;
        double media;
        Scanner teclado=new Scanner(System.in);

        System.out.print("Nota 1: ");
        nota1=teclado.nextInt();
        System.out.print("Nota 2: ");
        nota2=teclado.nextInt();

        media=(nota1+nota2)/2;
        System.out.println("Media=" + media);
    }
}
