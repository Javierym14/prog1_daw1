package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
	// write your code here
        int nota1, nota2, nota3, media;
        Scanner teclado=new Scanner(System.in);

        System.out.print("Nota 1: ");
        nota1=teclado.nextInt();
        System.out.print("Nota 2: ");
        nota2=teclado.nextInt();
        System.out.print("Nota 3: ");
        nota3=teclado.nextInt();

        media=(int) ((nota1+nota2+nota3)/3);

        System.out.println("Media="+ media);

    }
}
