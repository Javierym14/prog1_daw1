package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
	// write your code here
        Scanner teclado;
        int grados;

        teclado=new Scanner(System.in);
        System.out.print("Introduce los grados centígrados:");
        grados=teclado.nextInt();
        System.out.println("Los grados centígrados en grados fahrenheit  es:");
        System.out.print(((grados * 9) / 5) + 32 );
    }
}
