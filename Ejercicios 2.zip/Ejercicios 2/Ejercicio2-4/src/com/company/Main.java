package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
	// write your code here
        Scanner teclado;
        int longitud;

        teclado=new Scanner(System.in);
        System.out.print("Introduce la longitud:");
        longitud=teclado.nextInt();
        System.out.println("La longitud en metros es:");
        System.out.print(longitud * 1609 );
    }
}
