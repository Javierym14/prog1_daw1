package com.company;

public class Main {

    public static void main(String[] args) {
	// write your code here
        int primerNumero=5;
        int segundoNumero=7;
        System.out.println("El resultado de la multiplicación es:");
        System.out.print(primerNumero * segundoNumero);
    }
}
