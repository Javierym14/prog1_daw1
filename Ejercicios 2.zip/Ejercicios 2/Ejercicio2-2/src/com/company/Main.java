package com.company;

public class Main {

    public static void main(String[] args) {
	// write your code here
        int primerNumero=10;
        int segundoNumero=2;
        System.out.println("El resto de la división es:");
        System.out.print(10 % 2);
    }
}
