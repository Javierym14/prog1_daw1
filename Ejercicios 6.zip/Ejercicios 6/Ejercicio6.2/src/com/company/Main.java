package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        // write your code here
        int numero;
        Scanner teclado;
        teclado = new Scanner(System.in);
        System.out.print("Introduce un número: ");
        numero = teclado.nextInt();

        switch (numero) {
            case 1:
                System.out.print("Uno");
                break;
            case 2:
                System.out.print("Dos");
                break;
            case 3:
                System.out.print("Tres");
                break;
            case 4:
                System.out.print("Cuatro");
                break;
            case 5:
                System.out.print("Cinco");
                break;
            case 6:
                System.out.print("Seis");
                break;
            case 7:
                System.out.print("Siete");
                break;
            case 8:
                System.out.print("Ocho");
                break;
            case 9:
                System.out.print("Nueve");
                break;
            case 10:
                System.out.print("Diez");
                break;
        }
    }
}

